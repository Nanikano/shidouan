﻿# 評価づくり（PC版）の起動：GitHubで最新版を確かめ、新しければ入れ替えてからEdgeのアプリ画面で開く
$ErrorActionPreference = "SilentlyContinue"
$dir   = Join-Path $env:LOCALAPPDATA "HyokaDukuri"
$app   = Join-Path $dir "hyoka.html"
$log   = Join-Path $dir "update.log"
$raw   = "https://raw.githubusercontent.com/Nanikano/shidouan/main/hyoka.html"
New-Item -ItemType Directory -Force -Path $dir | Out-Null
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Get-Ver([string]$text){ if($text -match 'name="hyoka-version" content="([\d.]+)"'){ return $Matches[1] } return $null }
function Is-Newer([string]$a,[string]$b){
  if(-not $b){ return $true }
  $x = $a.Split("."); $y = $b.Split(".")
  for($i=0; $i -lt [Math]::Max($x.Length,$y.Length); $i++){
    $p = 0; $q = 0
    if($i -lt $x.Length){ $p = [int]$x[$i] }
    if($i -lt $y.Length){ $q = [int]$y[$i] }
    if($p -ne $q){ return ($p -gt $q) }
  }
  return $false
}
function Log([string]$m){ Add-Content -Path $log -Value ((Get-Date -Format "yyyy-MM-dd HH:mm:ss") + " " + $m) -Encoding UTF8 }

$localVer = $null
if(Test-Path $app){ $localVer = Get-Ver ([IO.File]::ReadAllText($app,[Text.Encoding]::UTF8)) }

# GitHubの最新版を確かめる（最長15秒。つながらなければ手元の版で開く）
$tmp = Join-Path $dir "hyoka.download"
try{
  Invoke-WebRequest -Uri ($raw + "?t=" + [DateTime]::Now.Ticks) -OutFile $tmp -UseBasicParsing -TimeoutSec 15 -Headers @{ "Cache-Control"="no-cache" }
  $text = [IO.File]::ReadAllText($tmp,[Text.Encoding]::UTF8)
  $remoteVer = Get-Ver $text
  if($remoteVer -and $text.Contains("</html>") -and (Is-Newer $remoteVer $localVer)){
    Move-Item -Force $tmp $app
    Log ("更新しました: " + $localVer + " -> " + $remoteVer)
  } else {
    Log ("最新です: 手元 " + $localVer + " / GitHub " + $remoteVer)
  }
} catch {
  Log ("GitHubを確かめられませんでした: " + $_.Exception.Message)
} finally {
  if(Test-Path $tmp){ Remove-Item -Force $tmp }
}

if(-not (Test-Path $app)){
  Add-Type -AssemblyName PresentationFramework
  [System.Windows.MessageBox]::Show("評価づくりを取り込めませんでした。インターネットにつないでから、もう一度開いてください。","評価づくり") | Out-Null
  exit 1
}

# Edgeのアプリ画面で開く（指導案づくりPC版と同じブラウザの保存場所なので、APIキーを共有）
$url = ([Uri]$app).AbsoluteUri
$edge = @(
  (Join-Path ${env:ProgramFiles(x86)} "Microsoft\Edge\Application\msedge.exe"),
  (Join-Path $env:ProgramFiles "Microsoft\Edge\Application\msedge.exe"),
  (Join-Path $env:LOCALAPPDATA "Microsoft\Edge\Application\msedge.exe")
) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if($edge){ Start-Process -FilePath $edge -ArgumentList ("--app=" + $url) }
else { Start-Process $url }
