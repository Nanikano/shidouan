﻿# 評価づくり（PC版）の導入：%LOCALAPPDATA%\HyokaDukuri に入れ、デスクトップにショートカットを作る
$ErrorActionPreference = "Stop"
$src = Split-Path -Parent $MyInvocation.MyCommand.Path
$dir = Join-Path $env:LOCALAPPDATA "HyokaDukuri"
New-Item -ItemType Directory -Force -Path $dir | Out-Null
foreach($f in @("hyoka.html","launch.ps1","launch.vbs","hyoka.ico")){
  $p = Join-Path $src $f
  if(Test-Path $p){
    # 手元のほうが新しい版なら、hyoka.html は上書きしない
    if($f -eq "hyoka.html" -and (Test-Path (Join-Path $dir $f))){ continue }
    Copy-Item -Force $p $dir
  }
}
$desktop = [Environment]::GetFolderPath("Desktop")
$ws = New-Object -ComObject WScript.Shell
$lnk = $ws.CreateShortcut((Join-Path $desktop "評価づくり.lnk"))
$lnk.TargetPath = Join-Path $env:WINDIR "System32\wscript.exe"
$lnk.Arguments = '"' + (Join-Path $dir "launch.vbs") + '"'
$lnk.WorkingDirectory = $dir
$lnk.IconLocation = (Join-Path $dir "hyoka.ico") + ",0"
$lnk.Description = "評価づくり（評価規準・指導と評価の計画）"
$lnk.Save()
Add-Type -AssemblyName PresentationFramework
[System.Windows.MessageBox]::Show("デスクトップに「評価づくり」を作りました。開くたびにGitHubで最新版を確かめ、自動で更新します。","評価づくり") | Out-Null
Start-Process -FilePath (Join-Path $env:WINDIR "System32\wscript.exe") -ArgumentList ('"' + (Join-Path $dir "launch.vbs") + '"')
