Set sh = CreateObject("WScript.Shell")
dir = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\HyokaDukuri"
sh.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & dir & "\launch.ps1""", 0, False
